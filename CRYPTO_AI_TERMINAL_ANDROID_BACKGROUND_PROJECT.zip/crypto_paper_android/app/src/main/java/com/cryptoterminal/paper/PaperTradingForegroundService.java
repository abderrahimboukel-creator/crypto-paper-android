package com.cryptoterminal.paper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class PaperTradingForegroundService extends Service {
    public static volatile boolean isRunning = false;
    private static final String CHANNEL_ID = "paper_trading_background";
    private static final int NOTIFICATION_ID = 7401;
    private static final String ACTION_STOP = "com.cryptoterminal.paper.STOP";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WebView workerWebView;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        isRunning = true;
        acquireWakeLock();
        if (workerWebView == null) mainHandler.post(this::createWorkerWebView);
        return START_STICKY;
    }

    private void createWorkerWebView() {
        if (workerWebView != null) return;
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        workerWebView = new WebView(getApplicationContext());
        workerWebView.setBackgroundColor(Color.TRANSPARENT);
        WebSettings settings = workerWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(false);
        settings.setBlockNetworkImage(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= 26) workerWebView.setRendererPriorityPolicy(
                WebView.RENDERER_PRIORITY_BOUND, true);
        workerWebView.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, android.webkit.WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        // Same HTTPS asset origin as the visible WebView: localStorage is shared by both.
        workerWebView.loadUrl("https://appassets.androidplatform.net/assets/index.html?worker=1");
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && (wakeLock == null || !wakeLock.isHeld())) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "CryptoPaperTerminal:PaperEngine");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) { }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "PAPER MODE background engine", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("استمرار مراقبة السوق والصفقات الافتراضية");
            channel.setShowBadge(false);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 10, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Intent stop = new Intent(this, PaperTradingForegroundService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 11, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentTitle("Crypto AI — PAPER MODE")
                .setContentText("المحرك يعمل: تحليل السوق ومراقبة الصفقات الافتراضية")
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(null, "إيقاف الخدمة", stopPending).build());
        return builder.build();
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Deliberately keep the foreground service alive when the app is swiped from Recents.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        isRunning = false;
        if (workerWebView != null) {
            mainHandler.post(() -> {
                try { workerWebView.stopLoading(); workerWebView.destroy(); }
                catch (Exception ignored) { }
                workerWebView = null;
            });
        }
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); }
        catch (Exception ignored) { }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
